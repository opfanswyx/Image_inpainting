clear all;
%se=strel('square',1);
I=imread('23.png');
I=I(:,:,1);
%J=imdilate(I,se);
%imshow(J);
%figure
%I2=imerode(I,se);
%imshow(I2);
I = imadjust(I);
imshow(I)
