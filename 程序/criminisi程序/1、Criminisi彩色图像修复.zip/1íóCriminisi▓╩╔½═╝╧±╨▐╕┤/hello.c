/**
 * A best exemplar finder.  Scans over the entire image (using a
 * sliding window) and finds the exemplar which minimizes the sum
 * squared error (SSE) over the to-be-filled pixels in the target
 * patch. 
 *
 * @author Sooraj Bhat  [Hp,rows,cols,w]=getpatch_autoc(x,y,sz,BW);
 */
#include "mex.h"
#include <limits.h>

 #include "mex.h" 

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{ 
mexPrintf("hello,world!\n"); 
}